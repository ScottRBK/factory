import { createFactoryForgetfulExtension } from "./src/bootstrap/factory.ts";

/** Factory-managed entrypoint. It never falls back to standalone Pi settings. */
export default createFactoryForgetfulExtension();
