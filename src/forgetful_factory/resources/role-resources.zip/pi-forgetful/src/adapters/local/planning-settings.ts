import { randomUUID } from "node:crypto";
import type { Stats } from "node:fs";
import { lstat, mkdir, open, realpath, rename, unlink } from "node:fs/promises";
import { join, resolve } from "node:path";
import type { PlanningPreferences } from "../../application/ports/planning.ts";
import { readPlanningPanel, updateUserSettings, userSettingsPath } from "../../config.ts";
import { readBoundedJson } from "./bounded-json.ts";

/** Preserves standalone settings reads and merge-based writes. */
export class LocalPlanningPreferences implements PlanningPreferences {
  constructor(private readonly path: string = userSettingsPath()) {}

  read(): Promise<boolean> { return readPlanningPanel(this.path); }

  write(enabled: boolean): Promise<void> {
    return updateUserSettings(this.path, { planning_panel: enabled });
  }
}

const MANAGED_STATE_SEGMENTS = [".factory", "data", "pi-forgetful"] as const;
const MANAGED_STATE_FILE = "planning.json";
const MANAGED_STATE_LABEL = "Managed planning state";

interface CheckedDirectory {
  path: string;
  identity: Stats;
}

function errorCode(error: unknown): string | undefined {
  return error instanceof Error && "code" in error
    ? (error as NodeJS.ErrnoException).code
    : undefined;
}

async function checkedDirectory(
  workspace: string,
  path: string,
  create: boolean,
): Promise<CheckedDirectory | undefined> {
  const lexicalWorkspace = resolve(workspace);
  const expected = join(lexicalWorkspace, ...MANAGED_STATE_SEGMENTS, MANAGED_STATE_FILE);
  if (resolve(path) !== expected) {
    throw new Error(`${MANAGED_STATE_LABEL} must stay inside the Factory workspace.`);
  }
  const workspacePath = await realpath(lexicalWorkspace);
  const workspaceIdentity = await lstat(workspacePath);
  if (!workspaceIdentity.isDirectory()) {
    throw new Error("Factory workspace must be a directory.");
  }
  let current = workspacePath;
  for (const segment of MANAGED_STATE_SEGMENTS) {
    const checked = await checkedDirectorySegment(current, segment, create);
    if (!checked) return undefined;
    current = checked;
  }
  return { path: current, identity: await lstat(current) };
}

async function checkedDirectorySegment(
  current: string,
  segment: string,
  create: boolean,
): Promise<string | undefined> {
  const next = join(current, segment);
  if (create) {
    try { await mkdir(next, { mode: 0o700 }); }
    catch (error) { if (errorCode(error) !== "EEXIST") throw error; }
  }
  let identity: Stats;
  try { identity = await lstat(next); }
  catch (error) {
    if (!create && errorCode(error) === "ENOENT") return undefined;
    throw error;
  }
  if (identity.isSymbolicLink() || !identity.isDirectory()) {
    throw new Error(`${MANAGED_STATE_LABEL} parent must be a directory, not a symbolic link.`);
  }
  const target = await realpath(next);
  if (target !== next) {
    throw new Error(`${MANAGED_STATE_LABEL} parent changed while it was being checked.`);
  }
  return target;
}

async function verifyDirectory(directory: CheckedDirectory): Promise<void> {
  const current = await lstat(directory.path);
  if (!current.isDirectory() || current.isSymbolicLink() ||
      current.dev !== directory.identity.dev || current.ino !== directory.identity.ino ||
      await realpath(directory.path) !== directory.path) {
    throw new Error(`${MANAGED_STATE_LABEL} parent changed while it was being used.`);
  }
}

function planningPanel(value: unknown): boolean {
  if (!value || typeof value !== "object" || Array.isArray(value) ||
      Object.keys(value).length !== 1 || !("planning_panel" in value) ||
      typeof value.planning_panel !== "boolean") {
    throw new TypeError(`${MANAGED_STATE_LABEL} must contain exactly planning_panel as a boolean.`);
  }
  return value.planning_panel;
}

function sameFile(left: Stats, right: Stats): boolean {
  return left.dev === right.dev && left.ino === right.ino && left.size === right.size &&
    left.mtimeMs === right.mtimeMs && left.ctimeMs === right.ctimeMs;
}

async function readState(
  directory: CheckedDirectory,
): Promise<{ enabled: boolean; identity: Stats } | undefined> {
  const path = join(directory.path, MANAGED_STATE_FILE);
  let before: Stats;
  try { before = await lstat(path); }
  catch (error) {
    if (errorCode(error) === "ENOENT") return undefined;
    throw error;
  }
  if (before.isSymbolicLink()) {
    throw new Error(`${MANAGED_STATE_LABEL} must be a regular file, not a symbolic link.`);
  }
  if (!before.isFile()) throw new Error(`${MANAGED_STATE_LABEL} must be a regular file.`);
  const value = await readBoundedJson(path, MANAGED_STATE_LABEL);
  const after = await lstat(path);
  if (!sameFile(before, after)) {
    throw new Error(`${MANAGED_STATE_LABEL} changed while it was being read.`);
  }
  await verifyDirectory(directory);
  return { enabled: planningPanel(value), identity: after };
}

async function currentState(path: string): Promise<Stats | undefined> {
  try { return await lstat(path); }
  catch (error) {
    if (errorCode(error) === "ENOENT") return undefined;
    throw error;
  }
}

function verifyCurrentState(
  previous: { identity: Stats } | undefined,
  current: Stats | undefined,
): void {
  if (current?.isSymbolicLink() || (current && !current.isFile())) {
    throw new Error(`${MANAGED_STATE_LABEL} must be a regular file, not a symbolic link.`);
  }
  if ((previous && (!current || !sameFile(previous.identity, current))) ||
      (!previous && current)) {
    throw new Error(`${MANAGED_STATE_LABEL} changed before it could be saved.`);
  }
}

async function verifySavedState(path: string, directory: CheckedDirectory): Promise<void> {
  const saved = await lstat(path);
  if (!saved.isFile() || saved.isSymbolicLink() || (saved.mode & 0o077) !== 0) {
    throw new Error(`${MANAGED_STATE_LABEL} was not saved as an owner-only regular file.`);
  }
  await verifyDirectory(directory);
}

async function removeTemporaryState(path: string): Promise<void> {
  try { await unlink(path); }
  catch (error) { if (errorCode(error) !== "ENOENT") throw error; }
}

/** Managed state owns only planning_panel and never merges existing JSON. */
export class ManagedPlanningPreferences implements PlanningPreferences {
  constructor(
    private readonly path: string,
    private readonly workspace: string,
  ) {}

  async read(): Promise<boolean> {
    const directory = await checkedDirectory(this.workspace, this.path, false);
    if (!directory) return false;
    return (await readState(directory))?.enabled ?? false;
  }

  async write(enabled: boolean): Promise<void> {
    const directory = await checkedDirectory(this.workspace, this.path, true);
    if (!directory) throw new Error(`${MANAGED_STATE_LABEL} parent is unavailable.`);
    const previous = await readState(directory);
    const target = join(directory.path, MANAGED_STATE_FILE);
    const temporary = join(directory.path,
      `${MANAGED_STATE_FILE}.${process.pid}.${randomUUID()}.tmp`);
    let renamed = false;
    const handle = await open(temporary, "wx", 0o600);
    try {
      try {
        await handle.writeFile(`${JSON.stringify({ planning_panel: enabled }, null, 2)}\n`, "utf8");
        await handle.sync();
      } finally { await handle.close(); }
      await verifyDirectory(directory);
      verifyCurrentState(previous, await currentState(target));
      await rename(temporary, target);
      renamed = true;
      await verifySavedState(target, directory);
    } catch (error) {
      if (!renamed) await removeTemporaryState(temporary);
      throw error;
    }
  }
}
