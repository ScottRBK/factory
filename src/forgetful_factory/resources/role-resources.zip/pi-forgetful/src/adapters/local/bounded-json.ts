import { constants } from "node:fs";
import { lstat, open, realpath } from "node:fs/promises";
import { dirname } from "node:path";

export const MAX_BOUNDED_JSON_BYTES = 64 * 1024;

/** Bounded, no-follow JSON read with file and immediate-parent identity checks. */
export async function readBoundedJson(
  path: string,
  label: string,
  maxBytes = MAX_BOUNDED_JSON_BYTES,
): Promise<unknown> {
  let handle: Awaited<ReturnType<typeof open>>;
  try {
    handle = await open(path,
      constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
  } catch (error) {
    if (error instanceof Error && "code" in error &&
        (error as NodeJS.ErrnoException).code === "ELOOP") {
      throw new Error(`${label} must be a regular file, not a symbolic link.`);
    }
    throw error;
  }
  try {
    const before = await handle.stat();
    if (!before.isFile()) throw new Error(`${label} must be a regular file.`);
    const original = await lstat(path);
    const parent = await realpath(dirname(path));
    const opened = await realpath(`/proc/self/fd/${handle.fd}`);
    if (original.dev !== before.dev || original.ino !== before.ino ||
        dirname(opened) !== parent) {
      throw new Error(`${label} changed before it could be read safely.`);
    }
    if (before.size > maxBytes) throw new Error(`${label} exceeds ${maxBytes} bytes.`);
    const bytes = Buffer.alloc(maxBytes + 1);
    let offset = 0;
    while (offset < bytes.length) {
      const result = await handle.read(bytes, offset, bytes.length - offset, offset);
      if (result.bytesRead === 0) break;
      offset += result.bytesRead;
    }
    if (offset > maxBytes) throw new Error(`${label} exceeds ${maxBytes} bytes.`);
    const after = await handle.stat();
    const current = await lstat(path);
    const currentParent = await realpath(dirname(path));
    const currentOpened = await realpath(`/proc/self/fd/${handle.fd}`);
    if (offset !== before.size || before.size !== after.size ||
        before.mtimeMs !== after.mtimeMs || before.ctimeMs !== after.ctimeMs ||
        current.dev !== before.dev || current.ino !== before.ino ||
        currentParent !== parent || dirname(currentOpened) !== parent) {
      throw new Error(`${label} changed while it was being read.`);
    }
    try { return JSON.parse(bytes.subarray(0, offset).toString("utf8")) as unknown; }
    catch (error) {
      if (error instanceof SyntaxError) throw new Error(`${label} must contain valid JSON.`);
      throw error;
    }
  } finally {
    await handle.close();
  }
}
