import { lstat, realpath } from "node:fs/promises";
import { dirname, isAbsolute, join } from "node:path";
import { readBoundedJson } from "../adapters/local/bounded-json.ts";
import { ManagedPlanningPreferences } from "../adapters/local/planning-settings.ts";
import type {
  ForgetfulConfig,
  PersistedUserSettings,
} from "../config.ts";
import {
  DEFAULT_FORGETFUL_RECALL_MODEL_TIMEOUT_MS,
  DEFAULT_FORGETFUL_TIMEOUT_MS,
  DEFAULT_MEMORY_CONTEXT_LIMIT_TOKENS,
  DEFAULT_RECALL_CONCURRENCY,
  DEFAULT_RECALL_DEADLINE_MS,
  loadForgetfulConfig,
} from "../config.ts";
import {
  createForgetfulExtension,
  type ForgetfulExtensionOptions,
} from "../extension.ts";

const TOKEN_ENV_NAME = /^[A-Za-z_]\w*$/;

/** Every key of the extension's settings file. */
const SETTING_KEYS = [
  "base_url", "token", "token_env", "timeout_ms", "enabled", "planning_panel", "capture",
  "capture_mode", "debug", "verbosity", "logging", "log_directory", "recall_model_timeout_ms",
  "recall_concurrency", "context_limit_tokens", "model",
] as const satisfies readonly (keyof PersistedUserSettings)[];
// Type-checking names any extension setting missing from the list above.
type UnlistedSetting = Exclude<keyof PersistedUserSettings, (typeof SETTING_KEYS)[number]>;
const ALL_SETTINGS_LISTED: [UnlistedSetting] extends [never] ? true : UnlistedSetting = true;
void ALL_SETTINGS_LISTED;

/** Settings that Factory sets: server, auth, state location and the plans panel. */
const FACTORY_OWNED_KEYS = [
  "base_url", "token", "token_env", "log_directory", "planning_panel",
] as const satisfies readonly (typeof SETTING_KEYS)[number][];

type JsonObject = Record<string, unknown>;

function object(value: unknown, label: string): JsonObject {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error(`${label} must be a JSON object.`);
  }
  return value as JsonObject;
}

function exactKeys(value: JsonObject, expected: string[], label: string): void {
  const keys = Object.keys(value).sort((left, right) => left.localeCompare(right));
  const wanted = [...expected].sort((left, right) => left.localeCompare(right));
  if (keys.length !== wanted.length || keys.some((key, index) => key !== wanted[index])) {
    throw new Error(`${label} must contain exactly: ${wanted.join(", ")}.`);
  }
}

/** Refuse keys Factory owns and unknown keys; the extension resolves every value. */
function checkSettingKeys(value: unknown): void {
  const data = object(value, "forgetful.json");
  const owned: readonly string[] = FACTORY_OWNED_KEYS;
  const known: readonly string[] = SETTING_KEYS;
  for (const key of Object.keys(data)) {
    if (owned.includes(key)) {
      throw new Error(`forgetful.json must not set ${key}; Factory sets it.`);
    }
    if (!known.includes(key)) throw new Error(`forgetful.json has unknown setting ${key}.`);
  }
}

function restEndpoint(input: string): string {
  const url = new URL(input);
  if (!["http:", "https:"].includes(url.protocol) || url.username || url.password ||
      url.search || url.hash) {
    throw new Error("FORGETFUL_SERVER must be an HTTP(S) URL without credentials or query data.");
  }
  const path = url.pathname;
  if (path === "/") url.pathname = "/api/v1";
  else if (path.endsWith("/mcp")) url.pathname = `${path.slice(0, -4)}/api/v1`;
  else throw new Error("FORGETFUL_SERVER has an unsupported path; use root or terminal /mcp.");
  return url.toString().replace(/\/$/, "");
}

function positiveProjectId(value: string | undefined): number {
  if (!value || !/^[1-9]\d*$/.test(value)) {
    throw new Error("FACTORY_FORGETFUL_PROJECT_ID must be a positive project ID.");
  }
  const id = Number(value);
  if (!Number.isSafeInteger(id)) {
    throw new TypeError("FACTORY_FORGETFUL_PROJECT_ID must be a safe integer.");
  }
  return id;
}

async function managedToken(path: string, env: NodeJS.ProcessEnv): Promise<{
  token?: string;
  tokenEnv?: string;
}> {
  try {
    const data = object(await readBoundedJson(path, "forgetful-auth.json"),
      "forgetful-auth.json");
    exactKeys(data, ["token_env"], "forgetful-auth.json");
    if (typeof data.token_env !== "string" || !TOKEN_ENV_NAME.test(data.token_env)) {
      throw new Error("forgetful-auth.json token_env must name an environment variable.");
    }
    const token = env[data.token_env];
    if (!token) {
      throw new Error(`Configured token environment variable ${data.token_env} is not set.`);
    }
    return { token, tokenEnv: data.token_env };
  } catch (error) {
    if (error instanceof Error && "code" in error &&
        (error as NodeJS.ErrnoException).code === "ENOENT") return {};
    throw error;
  }
}

function unavailableConfig(
  status: "local" | "invalid",
  message: string,
  workspace = "",
): ForgetfulConfig {
  const stateRoot = workspace ? join(workspace, ".factory/data/pi-forgetful") : "";
  return {
    enabled: false,
    planningEnabled: false,
    planningPanel: false,
    captureMode: "off",
    verbosity: "warning",
    logging: "off",
    logDirectory: stateRoot ? join(stateRoot, "logs") : "",
    scope: "project",
    scopeSource: "project",
    instance: { baseUrl: "", timeoutMs: DEFAULT_FORGETFUL_TIMEOUT_MS },
    recallDeadlineMs: DEFAULT_RECALL_DEADLINE_MS,
    recallModelTimeoutMs: DEFAULT_FORGETFUL_RECALL_MODEL_TIMEOUT_MS,
    recallConcurrency: DEFAULT_RECALL_CONCURRENCY,
    contextLimitTokens: DEFAULT_MEMORY_CONTEXT_LIMIT_TOKENS,
    prompts: {},
    warnings: [message],
    managed: { status, message, workspace },
    queueRoot: stateRoot ? join(stateRoot, "queues") : undefined,
    paths: {
      userSettings: stateRoot ? join(stateRoot, "planning.json") : "",
      projectSettings: "",
    },
  };
}

async function loadManagedConfig(env: NodeJS.ProcessEnv): Promise<ForgetfulConfig> {
  const instance = env.FACTORY_FORGETFUL_INSTANCE;
  const workspaceInput = env.FACTORY_WORKSPACE;
  const agentFileInput = env.FACTORY_FOREMAN_AGENT_FILE;
  if (instance === "local") {
    const message = "Managed Foreman local memory is unavailable; " +
      "ordinary Factory CLI planning remains available.";
    return unavailableConfig("local", message, workspaceInput ?? "");
  }
  try {
    if (instance !== "server") {
      throw new Error("FACTORY_FORGETFUL_INSTANCE must select server mode.");
    }
    if (!workspaceInput || !agentFileInput || !isAbsolute(workspaceInput) ||
        !isAbsolute(agentFileInput)) {
      throw new Error("Factory workspace and Foreman agent file must be absolute paths.");
    }
    const workspace = workspaceInput;
    const agentFile = agentFileInput;
    const rootBefore = await lstat(agentFile);
    let definitionValue: unknown;
    if (!rootBefore.isSymbolicLink()) {
      definitionValue = await readBoundedJson(agentFile, "Foreman agent definition");
    } else {
      const target = await realpath(agentFile);
      definitionValue = await readBoundedJson(target, "Foreman agent definition");
      const rootAfter = await lstat(agentFile);
      const currentTarget = await realpath(agentFile);
      if (!rootAfter.isSymbolicLink() || rootBefore.dev !== rootAfter.dev ||
          rootBefore.ino !== rootAfter.ino || rootBefore.size !== rootAfter.size ||
          rootBefore.mtimeMs !== rootAfter.mtimeMs || rootBefore.ctimeMs !== rootAfter.ctimeMs ||
          currentTarget !== target) {
        throw new Error("Foreman agent definition selection changed while it was being read.");
      }
    }
    const definition = object(definitionValue, "Foreman agent definition");
    object(definition.agent, "Foreman agent definition agent");
    const directory = dirname(agentFile);
    const settingsPath = join(directory, "forgetful.json");
    checkSettingKeys(await readBoundedJson(settingsPath, "forgetful.json"));
    const auth = await managedToken(join(directory, "forgetful-auth.json"), env);
    const projectId = positiveProjectId(env.FACTORY_FORGETFUL_PROJECT_ID);
    if (!env.FORGETFUL_SERVER) throw new Error("FORGETFUL_SERVER is required in server mode.");
    const baseUrl = restEndpoint(env.FORGETFUL_SERVER);
    const stateRoot = join(workspace, ".factory/data/pi-forgetful");
    const planningPath = join(stateRoot, "planning.json");
    const planningPanel = await new ManagedPlanningPreferences(planningPath, workspace).read();
    // The extension's own rules, defaults and warnings. forgetful.json is the only settings
    // layer, so it is also the project file; the key check refuses scope.
    const settings = await loadForgetfulConfig({
      cwd: workspace, agentDir: stateRoot, trusted: true, env,
      userSettingsPath: settingsPath, projectSettingsPath: settingsPath,
    });
    const status = settings.enabled ? "ready" : "memory-off";
    const taskWindow = `private task window up to ${settings.contextLimitTokens} tokens.`;
    const message = settings.enabled
      ? `Managed Foreman memory uses fixed project #${projectId}; ${taskWindow}`
      : `Managed Foreman memory is off; planning uses fixed project #${projectId}; ${taskWindow}`;
    return {
      enabled: settings.enabled,
      planningEnabled: true,
      planningPanel,
      captureMode: settings.captureMode,
      verbosity: settings.verbosity,
      logging: settings.logging,
      logDirectory: join(stateRoot, "logs"),
      scope: "project",
      scopeSource: "project",
      instance: { baseUrl, ...auth, timeoutMs: settings.instance.timeoutMs },
      recallDeadlineMs: settings.recallDeadlineMs,
      recallModelTimeoutMs: settings.recallModelTimeoutMs,
      recallConcurrency: settings.recallConcurrency,
      contextLimitTokens: settings.contextLimitTokens,
      model: settings.model,
      prompts: {},
      warnings: settings.warnings,
      managed: { status, message, projectId, workspace },
      queueRoot: join(stateRoot, "queues"),
      paths: { userSettings: planningPath, projectSettings: "" },
    };
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error);
    return unavailableConfig("invalid", `Managed Foreman memory is unavailable: ${reason}`,
      workspaceInput ?? "");
  }
}

export function createFactoryForgetfulExtension(
  options: Omit<ForgetfulExtensionOptions, "loadConfig" | "managed"> = {},
) {
  return createForgetfulExtension({
    ...options,
    managed: true,
    loadConfig: () => loadManagedConfig(process.env),
  });
}

