export type Scope = "global" | "project";
export type CaptureMode = "auto" | "observe" | "off";

export interface Project {
  id: number;
  name: string;
  repo_name?: string | null;
  description?: string;
}

export interface ProjectInput {
  name: string;
  description: string;
  repo_name: string;
}

export interface MemoryInput {
  title: string;
  content: string;
  context: string;
  keywords: string[];
  tags: string[];
  importance?: number;
  project_ids: number[];
  source_repo?: string;
  source_files?: string[];
  source_url?: string;
  encoding_version?: string;
  document_ids?: number[];
  code_artifact_ids?: number[];
  file_ids?: number[];
}

export interface Provenance {
  source_repo?: string;
  source_files?: string[];
  source_url?: string;
  encoding_version?: string;
}

export type EntityType = "Organization" | "Individual" | "Team" | "Device" | "System" | "Other";

export interface EntityInput extends Provenance {
  name: string;
  entity_type: EntityType;
  custom_type?: string;
  notes?: string;
  tags: string[];
  aka: string[];
  project_ids: number[];
}

export interface Entity extends EntityInput {
  id: number;
  updated_at?: string;
}

export interface EntityRelationshipInput extends Provenance {
  source_entity_id: number;
  target_entity_id: number;
  relationship_type: string;
}

export interface EntityRelationship extends EntityRelationshipInput {
  id: number;
}

export interface DocumentInput extends Provenance {
  title: string;
  description: string;
  content: string;
  document_type?: string;
  tags: string[];
  project_id?: number | null;
}

export interface Document extends DocumentInput {
  id: number;
  updated_at?: string;
}

export type DocumentSummary = Omit<Document, "content">;

export interface CodeArtifactInput extends Provenance {
  title: string;
  description: string;
  code: string;
  language: string;
  tags: string[];
  project_id?: number | null;
}

export interface CodeArtifact extends CodeArtifactInput {
  id: number;
  updated_at?: string;
}

export type CodeArtifactSummary = Omit<CodeArtifact, "code">;

export interface FileSummary {
  id: number;
  filename: string;
  description: string;
  mime_type: string;
  size_bytes: number;
  tags: string[];
  project_id?: number | null;
}

export interface StoredFile extends FileSummary {
  data: string;
}

/** Rich knowledge is optional for adapters that only support atomic memories. */
export interface KnowledgeClient {
  searchEntities(query: string, limit?: number, signal?: AbortSignal): Promise<Entity[]>;
  getEntity(id: number, signal?: AbortSignal): Promise<Entity>;
  createEntity(input: EntityInput, signal?: AbortSignal): Promise<Entity>;
  updateEntity(id: number, input: Partial<EntityInput>, signal?: AbortSignal): Promise<Entity>;
  getEntityMemories(id: number, signal?: AbortSignal): Promise<{ id: number; title: string }[]>;
  linkEntityMemory(entityId: number, memoryId: number, signal?: AbortSignal): Promise<void>;
  getRelationships(id: number, signal?: AbortSignal): Promise<EntityRelationship[]>;
  createRelationship(
    input: EntityRelationshipInput, signal?: AbortSignal,
  ): Promise<EntityRelationship>;
  listDocuments(projectId?: number, signal?: AbortSignal): Promise<DocumentSummary[]>;
  getDocument(id: number, signal?: AbortSignal): Promise<Document>;
  createDocument(input: DocumentInput, signal?: AbortSignal): Promise<Document>;
  updateDocument(
    id: number, input: Partial<DocumentInput>, signal?: AbortSignal,
  ): Promise<Document>;
  listCodeArtifacts(projectId?: number, signal?: AbortSignal): Promise<CodeArtifactSummary[]>;
  getCodeArtifact(id: number, signal?: AbortSignal): Promise<CodeArtifact>;
  createCodeArtifact(input: CodeArtifactInput, signal?: AbortSignal): Promise<CodeArtifact>;
  updateCodeArtifact(
    id: number, input: Partial<CodeArtifactInput>, signal?: AbortSignal,
  ): Promise<CodeArtifact>;
  listFiles(projectId?: number, signal?: AbortSignal): Promise<FileSummary[]>;
  getFile(id: number, signal?: AbortSignal): Promise<StoredFile>;
  updateMemory(id: number, input: Partial<MemoryInput>, signal?: AbortSignal): Promise<Memory>;
  linkMemories(id: number, relatedIds: number[], signal?: AbortSignal): Promise<void>;
  unlinkMemories?(id: number, targetId: number, signal?: AbortSignal): Promise<void>;
}

export interface Memory extends MemoryInput {
  id: number;
  is_obsolete: boolean;
  superseded_by?: number | null;
  obsolete_reason?: string | null;
  obsoleted_at?: string | null;
  linked_memory_ids?: number[];
  access_count?: number;
  last_accessed_at?: string | null;
  updated_at?: string;
}

export interface LinkedMemory {
  memory: Memory;
  link_source_id: number;
}

/** The complete grouped response returned by the Forgetful query_memory API. */
export interface MemorySearchResult {
  query: string;
  primary_memories: Memory[];
  linked_memories: LinkedMemory[];
  total_count: number;
  token_count: number;
  truncated: boolean;
}

export interface SearchRequest {
  query: string;
  query_context: string;
  project_ids?: number[];
  strict_project_filter: boolean;
  k?: number;
  include_links?: boolean;
  max_links?: number;
  max_links_per_primary?: number;
}

export interface MemoryCreateResult {
  id: number;
  /** IDs returned by creation, not historical links inferred by a later read. */
  autoLinkedMemoryIds?: number[];
}

export interface ForgetfulClient {
  knowledge?: KnowledgeClient;
  getMemoryEntityIds?(id: number, signal?: AbortSignal): Promise<number[]>;
  search(request: SearchRequest, signal?: AbortSignal): Promise<Memory[]>;
  /** Query memory while retaining the server's grouped result and budget metadata. */
  queryMemory?(request: SearchRequest, signal?: AbortSignal): Promise<MemorySearchResult>;
  /** Exact project lookup for managed callers that must never enumerate alternatives. */
  getProject?(id: number, signal?: AbortSignal): Promise<Project>;
  listProjects(repoName?: string, signal?: AbortSignal): Promise<Project[]>;
  createProject(input: ProjectInput, signal?: AbortSignal): Promise<Project>;
  linkProject(
    id: number,
    repoName: string,
    signal?: AbortSignal,
  ): Promise<Project>;
  create(input: MemoryInput, signal?: AbortSignal): Promise<MemoryCreateResult>;
  get(id: number, signal?: AbortSignal): Promise<Memory>;
  obsolete?(
    id: number, reason: string, replacementId?: number, signal?: AbortSignal,
  ): Promise<void>;
  supersede(
    id: number,
    replacementId: number,
    reason: string,
    signal?: AbortSignal,
  ): Promise<void>;
}

export interface ModelRequest {
  purpose: "classification" | "recall-review" | "capture" | "overlap";
  policy: string;
  input: unknown;
  /** Ordered historical records, kept separate from the current task and its instructions. */
  conversation?: readonly unknown[];
  /** Persist the initial compacted historical view; never private task/tool turns. */
  onConversationCompacted?: (view: CompactedConversation) => Promise<void>;
  signal?: AbortSignal;
  /** Required for decisions/actions; contextual summaries use the separate compaction path. */
  submission: ModelSubmissionTool;
  /** Task-specific read capabilities. Private models never inherit the main agent's tools. */
  readTools?: ModelReadTool[];
  /**
   * Concurrent reads in one tool-call batch: 1–8, default 1.
   * Recall opts in; capture stays serial.
   */
  readConcurrency?: number;
  /** Task-owned state refreshed after all results in a read batch, before the next model turn. */
  readBatchContext?: () => unknown;
  /** Diagnostic correlation only; never included in the model input. */
  diagnosticContext?: {
    jobId?: string;
    sessionId?: string;
    branchId?: string;
    candidateId?: string;
  };
}

/** Explicit local evidence result; ordinary service JSON must never be treated as native images. */
export class ModelEvidencePage {
  constructor(
    readonly entryId: string,
    readonly record: unknown,
    readonly offset: number,
    readonly limit: number,
  ) {}
}

/** Explicit failed read with structured detail; ordinary service JSON remains ordinary data. */
export class ModelReadErrorResult {
  constructor(readonly value: unknown) {}
}

export interface ModelReadTool {
  name: string;
  description: string;
  parameters: unknown;
  execute(input: unknown, signal: AbortSignal): Promise<unknown>;
}

/** Task-level permission/lifecycle stop, not a tool error the model may work around. */
export class ModelTaskPause extends Error {}

export interface ModelSubmissionTool {
  name: string;
  description: string;
  parameters: unknown;
  validate(input: unknown): unknown;
  /** Bounded rejection detail for debug output, including adapter-level failures. */
  onRejection?(reason: string, input?: unknown): void;
}

export class ModelSubmissionError extends Error {
  constructor(
    message: string,
    readonly rejectionReasons: string[] = [],
  ) {
    super(message, rejectionReasons.length > 0
      ? { cause: new Error(rejectionReasons.slice(-3).join("; ")) }
      : undefined);
  }
}

export interface MemoryModelClient {
  /** One bounded source-history preparation slice, before charging capture extraction calls. */
  prepareCapture?(request: ModelRequest): Promise<"ready" | "progress">;
  complete(request: ModelRequest): Promise<unknown>;
}

export interface WorkContext {
  cwd: string;
  repoName?: string;
  project?: Project;
  /** Local capture queued before the server could verify its project mapping. */
  projectDiscoveryPending?: boolean;
  sessionId: string;
  branchId: string;
}

export interface EvidenceEntry {
  id: string;
  role: "user" | "assistant" | "toolResult";
  text: string;
  toolName?: string;
  toolCallId?: string;
  isError?: boolean;
  details?: unknown;
}

export interface CaptureHistorySummary {
  throughEntryId: string;
  text: string;
}

export interface CompactedConversation {
  summary: string;
  summarizedThroughEntryId: string;
  retainedConversation: readonly unknown[];
}

export interface CaptureSnapshot {
  id: string;
  context: WorkContext;
  instanceId: string;
  entries: EvidenceEntry[];
  /** Sanitized Pi entry records in root-to-pinned-leaf order; never evidence by role alone. */
  conversation?: readonly unknown[];
  conversationCoverage?: "complete" | "legacy-partial" | "summarized";
  /** Original native source records retained independently of the compacted model view. */
  sourceConversation?: readonly unknown[];
  historySummary?: CaptureHistorySummary;
  /** Previously processed boundary, independent of the historical context cutoff. */
  processedThroughEntryId?: string | null;
  leafEntryId?: string;
  finalEntryId: string;
  mode: CaptureMode;
  scope: Scope;
  policy: string;
  modelVersion: string;
  createdAt: string;
}
