import { Type } from "typebox";
import type {
  CodeArtifact,
  CodeArtifactInput,
  Document,
  DocumentInput,
  Entity,
  EntityInput,
  EntityRelationshipInput,
  EntityType,
  ForgetfulClient,
  KnowledgeClient,
  Memory,
  MemorySearchResult,
  MemoryInput,
  Provenance,
  Scope,
  StoredFile,
} from "./contracts.ts";
import { replacementMemoryContext } from "./memory-context.ts";
import { hasSensitiveData } from "./privacy.ts";

export interface KnowledgeToolContext {
  cwd: string;
  repoName?: string;
  commit?: string;
  project?: { id: number; name: string };
  scope: Scope;
}

export type ToolText = { type: "text"; text: string };
export type ToolImage = { type: "image"; data: string; mimeType: string };
export interface KnowledgeToolResult {
  content: Array<ToolText | ToolImage>;
  details: Record<string, unknown>;
  file?: StoredFile;
}

const positiveId = Type.Integer({ minimum: 1 });
const operation = Type.Union([
  Type.Literal("list_projects"),
  Type.Literal("search_memories"),
  Type.Literal("get_memory"),
  Type.Literal("search_entities"),
  Type.Literal("get_entity"),
  Type.Literal("get_entity_memories"),
  Type.Literal("get_relationships"),
  Type.Literal("list_documents"),
  Type.Literal("get_document"),
  Type.Literal("list_code_artifacts"),
  Type.Literal("get_code_artifact"),
  Type.Literal("list_files"),
  Type.Literal("get_file"),
], {
  description: "Read operation; each field names the operations requiring it.",
});
const writeOperation = Type.Union([
  Type.Literal("create_memory"),
  Type.Literal("update_memory"),
  Type.Literal("supersede_memory"),
  Type.Literal("link_memories"),
  Type.Literal("create_entity"),
  Type.Literal("update_entity"),
  Type.Literal("link_entity_memory"),
  Type.Literal("create_relationship"),
  Type.Literal("create_document"),
  Type.Literal("update_document"),
  Type.Literal("create_code_artifact"),
  Type.Literal("update_code_artifact"),
]);
const strings = Type.Array(Type.String(), { maxItems: 10 });
const ids = Type.Array(positiveId, { maxItems: 100 });
function leftoverSearchField(description: string) {
  return Type.Optional(Type.Unknown({ description }));
}
const DEFAULT_RECORD_LIMIT = 50;
const MAX_RECORD_LIMIT = 100;
const DEFAULT_CONTENT_LIMIT = 4_000;
const MAX_LIST_RESULT_CHARS = 16_000;

/** Keep this root schema as an object; some providers reject a root anyOf/oneOf. */
export const KNOWLEDGE_READ_PARAMETERS = Type.Object({
  operation,
  repo_name: leftoverSearchField(
    "Exact owner/repo filter for list_projects; does not widen read scope.",
  ),
  query: leftoverSearchField(
    "Required: semantic topic for search_memories; name/alias substring for search_entities.",
  ),
  query_context: leftoverSearchField(
    "Required for search_memories: task intent for optional reranking, not retrieval; " +
      "put search terms in query.",
  ),
  project_id: leftoverSearchField(
    "Exact integer project ID for list/search; project scope permits only the current project.",
  ),
  memory_id: leftoverSearchField("Required for get_memory."),
  entity_id: leftoverSearchField(
    "Required for get_entity, get_entity_memories, and get_relationships.",
  ),
  document_id: leftoverSearchField("Required for get_document."),
  code_artifact_id: leftoverSearchField("Required for get_code_artifact."),
  file_id: leftoverSearchField("Required for get_file."),
  k: leftoverSearchField(
    "Primary search_memories results: 1-20, default 3.",
  ),
  max_links_per_primary: leftoverSearchField(
    "Links per primary search_memories result: 0-10, default 5.",
  ),
  limit: Type.Optional(Type.Integer({
    minimum: 1, maximum: 5_000,
    description: "Page size: lists/search_entities max 100 records; document/code/file " +
      "content max 5000 characters. search_memories uses k.",
  })),
  offset: Type.Optional(Type.Integer({
    minimum: 0, maximum: 10_000_000,
    description: "Lists: item offset (use returned next_offset); text: character offset. " +
      "No search_memories pagination.",
  })),
  include_links: leftoverSearchField(
    "Include linked memories for search_memories; defaults to true.",
  ),
});

export const KNOWLEDGE_WRITE_PARAMETERS = Type.Object({
  operation: writeOperation,
  project_id: Type.Optional(Type.Integer({
    minimum: 1,
    description: "Optional explicit destination project; defaults to the verified current project.",
  })),
  memory_id: Type.Optional(positiveId),
  replacement_memory_id: Type.Optional(positiveId),
  entity_id: Type.Optional(positiveId),
  source_entity_id: Type.Optional(positiveId),
  target_entity_id: Type.Optional(positiveId),
  document_id: Type.Optional(positiveId),
  code_artifact_id: Type.Optional(positiveId),
  related_memory_ids: Type.Optional(ids),
  name: Type.Optional(Type.String({ minLength: 1, maxLength: 200 })),
  title: Type.Optional(Type.String({ minLength: 1, maxLength: 500,
    description: "Maximum 200 characters for memories; 500 for documents and code artifacts." })),
  content: Type.Optional(Type.String({ minLength: 1, maxLength: 100_000,
    description: "Maximum 2000 characters for memories; 100000 for documents." })),
  context: Type.Optional(Type.String({ minLength: 1, maxLength: 500 })),
  description: Type.Optional(Type.String({ minLength: 1, maxLength: 5_000 })),
  code: Type.Optional(Type.String({ minLength: 1, maxLength: 50_000 })),
  language: Type.Optional(Type.String({ minLength: 1, maxLength: 100 })),
  document_type: Type.Optional(Type.String({ maxLength: 100 })),
  entity_type: Type.Optional(Type.String({ maxLength: 30 })),
  custom_type: Type.Optional(Type.String({ maxLength: 100 })),
  notes: Type.Optional(Type.String({ maxLength: 4_000 })),
  relationship_type: Type.Optional(Type.String({ minLength: 1, maxLength: 100 })),
  reason: Type.Optional(Type.String({ minLength: 1, maxLength: 1_000 })),
  keywords: Type.Optional(strings),
  tags: Type.Optional(strings),
  aka: Type.Optional(strings),
  source_files: Type.Optional(Type.Array(Type.String({ minLength: 1 }), {
    maxItems: 100,
  })),
  encoding_version: Type.Optional(
    Type.String({ minLength: 7, maxLength: 50, pattern: "^[a-fA-F0-9]+$" }),
  ),
  document_ids: Type.Optional(ids),
  code_artifact_ids: Type.Optional(ids),
  file_ids: Type.Optional(ids),
  importance: Type.Optional(Type.Integer({ minimum: 1, maximum: 10 })),
});

export type KnowledgeReadRequest = Record<string, unknown> & { operation: string };
export type KnowledgeWriteRequest = Record<string, unknown> & { operation: string };

const READ_OPS = new Set([
  "list_projects", "search_memories", "get_memory", "search_entities", "get_entity",
  "get_entity_memories", "get_relationships", "list_documents", "get_document",
  "list_code_artifacts", "get_code_artifact", "list_files", "get_file",
]);
const WRITE_OPS = new Set([
  "create_memory", "update_memory", "supersede_memory", "link_memories", "create_entity",
  "update_entity", "link_entity_memory", "create_relationship", "create_document",
  "update_document", "create_code_artifact", "update_code_artifact",
]);
const ENTITY_TYPES = new Set(["Organization", "Individual", "Team", "Device", "System", "Other"]);

function isEntityType(value: unknown): value is EntityType {
  return typeof value === "string" && ENTITY_TYPES.has(value);
}

function record(value: unknown, label: string): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new Error(`${label} must be an object.`);
  return value as Record<string, unknown>;
}

function requiredText(value: unknown, field: string, max?: number): string {
  if (typeof value !== "string" || !value.trim() ||
      (max !== undefined && value.length > max)) {
    const constraint = max === undefined ? "non-empty text" : `1–${max} characters`;
    throw new Error(`${field} is required and must contain ${constraint} (not whitespace).`);
  }
  return value;
}

function optionalText(value: unknown, field: string, max: number): string | undefined {
  return value === undefined ? undefined : requiredText(value, field, max);
}

function requiredId(value: unknown, field: string): number {
  if (value === undefined)
    throw new Error(`${field} is required.`);
  if (!Number.isSafeInteger(value) || Number(value) < 1)
    throw new Error(`${field} must be a positive integer.`);
  return Number(value);
}

function optionalId(value: unknown, field: string): number | undefined {
  return value === undefined ? undefined : requiredId(value, field);
}

function boundedId(value: unknown, field: string, maximum: number): number | undefined {
  const result = optionalId(value, field);
  if (result !== undefined && result > maximum)
    throw new Error(`${field} must be at most ${maximum}.`);
  return result;
}

function requiredIds(value: unknown, field: string): number[] {
  if (!Array.isArray(value) || value.length > 100 || value.length === 0)
    throw new Error(`${field} must contain one to 100 IDs.`);
  return value.map((item) => requiredId(item, field));
}

function optionalIds(value: unknown, field: string): number[] | undefined {
  return value === undefined ? undefined : requiredIds(value, field);
}

function requiredStrings(
  value: unknown,
  field: string,
  maxItems = 100,
): string[] {
  if (!Array.isArray(value) || value.length > maxItems)
    throw new Error(`${field} must be an array with at most ${maxItems} non-empty strings.`);
  return value.map((item) => requiredText(item, field));
}

function optionalStrings(
  value: unknown,
  field: string,
  maxItems = 100,
): string[] | undefined {
  return value === undefined ? undefined : requiredStrings(value, field, maxItems);
}

function optionalImportance(value: unknown): number | undefined {
  if (value === undefined) return undefined;
  if (!Number.isSafeInteger(value) || Number(value) < 1 || Number(value) > 10)
    throw new Error("importance must be an integer from 1 to 10.");
  return Number(value);
}

function commit(value: unknown): string | undefined {
  const result = optionalText(value, "encoding_version", 50);
  if (result !== undefined && !/^[a-fA-F0-9]{7,50}$/.test(result))
    throw new Error("encoding_version must be a Git commit SHA.");
  return result;
}

function checkOperation(value: unknown, choices: Set<string>): string {
  if (typeof value !== "string" || !choices.has(value))
    throw new Error("Unknown Forgetful knowledge operation.");
  return value;
}

function containsSensitiveData(value: unknown): boolean {
  if (typeof value === "string") return hasSensitiveData(value);
  if (Array.isArray(value)) return value.some(containsSensitiveData);
  if (value && typeof value === "object")
    return Object.values(value).some(containsSensitiveData);
  return false;
}

function rejectSensitiveInput(value: unknown): void {
  if (containsSensitiveData(value))
    throw new Error("Knowledge writes cannot contain sensitive data.");
}

function need(input: Record<string, unknown>, fields: Array<[string, number]>): void {
  for (const [field, max] of fields) requiredText(input[field], field, max);
}

function validateReadSearch(input: Record<string, unknown>, op: string): void {
  if (op !== "search_memories") return;
  // This port translates a boolean to REST's traversal depth 0/1. Other server fields
  // pass through unchanged so Forgetful can return its own validation errors.
  if (input.include_links !== undefined && typeof input.include_links !== "boolean")
    throw new Error("include_links must be a boolean.");
  if (input.limit !== undefined)
    throw new Error("search_memories uses k; limit is not supported.");
  if (input.offset !== undefined)
    throw new Error("search_memories does not support offset pagination.");
}

function validateReadPagination(input: Record<string, unknown>, op: string): void {
  const listOperations = new Set(["list_projects", "search_entities",
    "get_entity_memories", "get_relationships",
    "list_documents", "list_code_artifacts", "list_files"]);
  if (listOperations.has(op)) boundedId(input.limit, "limit", 100);
  if (input.offset !== undefined &&
      (!Number.isSafeInteger(input.offset) || Number(input.offset) < 0 ||
        Number(input.offset) > 10_000_000))
    throw new Error("offset must be a non-negative integer.");
  if (op !== "search_memories" && op !== "search_entities" && !listOperations.has(op))
    boundedId(input.limit, "limit", 5_000);
}

/** Keep local paging and read-only access checks for callers that bypass Pi's schema. */
export function validateKnowledgeReadRequest(value: unknown): KnowledgeReadRequest {
  const input = record(value, "Knowledge read arguments");
  const op = checkOperation(input.operation, READ_OPS);
  validateReadSearch(input, op);
  // k, include_links and max_links_per_primary are search_memories fields. The flat schema
  // advertises them on every op with loose leftover types, so Pi and runtime ignore them
  // rather than reject other operations.
  validateReadPagination(input, op);
  return input as KnowledgeReadRequest;
}

function validateEntityFields(input: Record<string, unknown>): void {
  if (input.entity_type !== undefined && !isEntityType(input.entity_type))
    throw new Error(`entity_type is invalid. Use ${[...ENTITY_TYPES].join(", ")}.`);
  optionalText(input.custom_type, "custom_type", 100);
  optionalText(input.notes, "notes", 4_000);
  if (input.entity_type === "Other" && input.custom_type === undefined)
    throw new Error("Other entities require custom_type.");
}

export function validateKnowledgeWriteRequest(value: unknown): KnowledgeWriteRequest {
  const input = record(value, "Knowledge write arguments");
  const op = checkOperation(input.operation, WRITE_OPS);
  optionalId(input.project_id, "project_id");
  switch (op) {
    case "create_memory":
      need(input, [["title", 200], ["content", 2_000], ["context", 500]]);
      requiredStrings(input.keywords, "keywords", 10);
      requiredStrings(input.tags, "tags", 10);
      break;
    case "update_memory":
      requiredId(input.memory_id, "memory_id");
      optionalText(input.title, "title", 200);
      optionalText(input.content, "content", 2_000);
      optionalText(input.context, "context", 500);
      optionalImportance(input.importance);
      break;
    case "supersede_memory":
      requiredId(input.memory_id, "memory_id");
      if (input.replacement_memory_id === undefined && input.content === undefined)
        throw new Error("supersede_memory needs replacement_memory_id or content.");
      optionalId(input.replacement_memory_id, "replacement_memory_id");
      requiredText(input.reason, "reason", 1_000);
      optionalText(input.title, "title", 200);
      optionalText(input.content, "content", 2_000);
      optionalText(input.context, "context", 500);
      optionalImportance(input.importance);
      if (requiredStrings(input.source_files, "source_files", 100).length === 0)
        throw new Error("source_files is required for supersession.");
      break;
    case "link_memories":
      requiredId(input.memory_id, "memory_id");
      if (requiredIds(input.related_memory_ids, "related_memory_ids").includes(
        input.memory_id as number,
      )) {
        throw new Error("A memory cannot link to itself; " +
          "remove memory_id from related_memory_ids.");
      }
      break;
    case "create_entity":
      need(input, [["name", 200], ["entity_type", 30]]);
      validateEntityFields(input);
      break;
    case "update_entity":
      requiredId(input.entity_id, "entity_id");
      optionalText(input.name, "name", 200);
      validateEntityFields(input);
      break;
    case "link_entity_memory":
      requiredId(input.entity_id, "entity_id");
      requiredId(input.memory_id, "memory_id");
      break;
    case "create_relationship":
      requiredId(input.source_entity_id, "source_entity_id");
      requiredId(input.target_entity_id, "target_entity_id");
      if (input.source_entity_id === input.target_entity_id)
        throw new Error("source_entity_id and target_entity_id must be different.");
      requiredText(input.relationship_type, "relationship_type", 100);
      break;
    case "create_document":
      need(input, [["title", 500], ["description", 5_000], ["content", 100_000]]);
      optionalText(input.document_type, "document_type", 100);
      break;
    case "update_document":
      requiredId(input.document_id, "document_id");
      optionalText(input.title, "title", 500);
      optionalText(input.description, "description", 5_000);
      optionalText(input.content, "content", 100_000);
      optionalText(input.document_type, "document_type", 100);
      break;
    case "create_code_artifact":
      need(input, [["title", 500], ["description", 5_000], ["code", 50_000], ["language", 100]]);
      break;
    case "update_code_artifact":
      requiredId(input.code_artifact_id, "code_artifact_id");
      optionalText(input.title, "title", 500);
      optionalText(input.description, "description", 5_000);
      optionalText(input.code, "code", 50_000);
      optionalText(input.language, "language", 100);
      break;
  }
  optionalStrings(input.source_files, "source_files", 100);
  optionalStrings(input.keywords, "keywords", 10);
  optionalStrings(input.tags, "tags", 10);
  optionalStrings(input.aka, "aka", 10);
  for (const field of ["document_ids", "code_artifact_ids", "file_ids"]) {
    // An explicit empty PUT list removes every attachment of that kind.
    if (op === "update_memory" && Array.isArray(input[field]) && input[field].length === 0)
      continue;
    optionalIds(input[field], field);
  }
  optionalImportance(input.importance);
  commit(input.encoding_version);
  return input as KnowledgeWriteRequest;
}

function rich(client: ForgetfulClient): KnowledgeClient {
  if (!client.knowledge) throw new Error("Rich Forgetful knowledge is unavailable.");
  return client.knowledge;
}

function currentProject(context: KnowledgeToolContext, requested?: number): number {
  if (!context.project) throw new Error("A verified current Forgetful project is required.");
  if (requested !== undefined && requested !== context.project.id)
    throw new Error("Knowledge operations must stay inside the current project.");
  return context.project.id;
}

interface ResolvedWriteProject {
  id: number;
  repoName?: string;
}

async function resolveWriteProject(
  client: ForgetfulClient,
  context: KnowledgeToolContext,
  requested: number | undefined,
  signal?: AbortSignal,
): Promise<ResolvedWriteProject> {
  const current = currentProject(context);
  if (requested === undefined || requested === current) {
    return { id: current, repoName: context.repoName };
  }
  const allProjects = await client.listProjects(undefined, signal);
  const matches = allProjects.filter((project) => project.id === requested);
  if (matches.length === 0) {
    throw new Error(
      `Destination project ${requested} was not found or is unavailable. ` +
      "Use list_projects to choose an existing assigned project.",
    );
  }
  if (matches.length > 1) {
    throw new Error(
      `Destination project ${requested} is ambiguous. ` +
      "Resolve the duplicate project records before writing.",
    );
  }
  const destination = matches[0]!;
  if (typeof destination.repo_name !== "string" || !destination.repo_name.trim()) {
    throw new Error(
      `Destination project ${requested} is not assigned to a repository. ` +
      "Link it before writing cross-project knowledge.",
    );
  }
  const sharedRepo = allProjects.filter(
    (project) => project.repo_name === destination.repo_name,
  );
  if (sharedRepo.length > 1) {
    throw new Error(
      `Destination project ${requested} is ambiguous. ` +
      "Resolve the duplicate project records before writing.",
    );
  }
  return { id: requested, repoName: destination.repo_name };
}

function inMemoryProject(memory: Memory, projectId: number): boolean {
  return memory.project_ids.includes(projectId);
}

function inEntityProject(entity: Entity, projectId: number): boolean {
  return entity.project_ids.includes(projectId);
}

function json(value: unknown): string {
  return JSON.stringify(value, null, 2) ?? "null";
}

function page(
  value: Document | CodeArtifact,
  field: "content" | "code",
  offset?: number,
  limit?: number,
): unknown {
  const start = offset ?? 0;
  const textValue = field === "content"
    ? (value as Document).content
    : (value as CodeArtifact).code;
  const requested = limit ?? DEFAULT_CONTENT_LIMIT;
  const end = Math.min(textValue.length, start + requested);
  return {
    ...value,
    [field]: textValue.slice(start, end),
    offset: start,
    limit: requested,
    total_length: textValue.length,
    truncated: end < textValue.length,
  };
}

function listPage<T>(
  values: T[],
  offset?: number,
  limit?: number,
): { items: T[]; offset: number; limit: number; total: number; truncated: boolean } {
  const start = offset ?? 0;
  const requested = Math.min(limit ?? DEFAULT_RECORD_LIMIT, MAX_RECORD_LIMIT);
  const items = values.slice(start, start + requested);
  return {
    items,
    offset: start,
    limit: requested,
    total: values.length,
    truncated: start + items.length < values.length,
  };
}

function boundedListPage<T>(
  values: T[],
  offset?: number,
  limit?: number,
): { items: unknown[]; offset: number; limit: number; total: number;
  truncated: boolean; next_offset: number } {
  const result = listPage(values, offset, limit);
  let items = result.items.map((item) => compactWriteValue(item));
  while (items.length > 1 && json({ items }).length > MAX_LIST_RESULT_CHARS)
    items = items.slice(0, -1);
  const nextOffset = result.offset + items.length;
  return {
    ...result,
    items,
    truncated: result.truncated || nextOffset < result.total,
    next_offset: nextOffset,
  };
}

function fileContent(
  file: StoredFile,
  offset?: number,
  limit?: number,
): { content: Array<ToolText | ToolImage>; kind: string } {
  const mime = file.mime_type.toLowerCase();
  const metadata = {
    id: file.id, filename: file.filename, mime_type: file.mime_type,
    size_bytes: file.size_bytes, project_id: file.project_id,
  };
  if (/^image\/(png|jpeg|gif|webp)$/.test(mime)) {
    return {
      kind: "image",
      content: [
        { type: "text", text: json(metadata) },
        { type: "image", data: file.data, mimeType: file.mime_type },
      ],
    };
  }
  if (mime.startsWith("text/") || /json|xml|javascript|typescript|yaml|toml|markdown/.test(mime)) {
    const decoded = Buffer.from(file.data, "base64").toString("utf8");
    const start = offset ?? 0;
    const requested = limit ?? DEFAULT_CONTENT_LIMIT;
    const chunk = decoded.slice(start, start + requested);
    return {
      kind: "text",
      content: [{
        type: "text",
        text: json({ ...metadata, text: chunk, offset: start, limit: requested,
          total_length: decoded.length, truncated: start + chunk.length < decoded.length }),
      }],
    };
  }
  return {
    kind: "binary",
    content: [{ type: "text", text: json({ ...metadata, binary: true }) }],
  };
}

function readResult(value: unknown, details: Record<string, unknown>): KnowledgeToolResult {
  return { content: [{ type: "text", text: json(value) }], details };
}

async function assertReadMemory(
  client: ForgetfulClient,
  id: number,
  context: KnowledgeToolContext,
  signal?: AbortSignal,
): Promise<Memory> {
  const value = await client.get(id, signal);
  if (context.scope === "project" && !inMemoryProject(value, currentProject(context)))
    throw new Error("The memory is outside the current project.");
  return value;
}

async function assertReadEntity(
  knowledge: KnowledgeClient,
  id: number,
  context: KnowledgeToolContext,
  signal?: AbortSignal,
): Promise<Entity> {
  const value = await knowledge.getEntity(id, signal);
  if (context.scope === "project" && !inEntityProject(value, currentProject(context)))
    throw new Error("The entity is outside the current project.");
  return value;
}

interface KnowledgeReadContext {
  client: ForgetfulClient;
  knowledge?: KnowledgeClient;
  request: KnowledgeReadRequest;
  context: KnowledgeToolContext;
  projectId?: number;
  signal?: AbortSignal;
}

function requireReadKnowledge(read: KnowledgeReadContext): KnowledgeClient {
  if (!read.knowledge) throw new Error("Rich Forgetful knowledge is unavailable.");
  return read.knowledge;
}

function requestedReadProject(read: KnowledgeReadContext): number | undefined {
  const requested = read.request.project_id as number | undefined;
  return read.context.scope === "project"
    ? currentProject(read.context, requested)
    : requested;
}

async function readProjects(read: KnowledgeReadContext): Promise<KnowledgeToolResult> {
  const repoName = read.request.repo_name as string | undefined;
  // An explicit, exact repo_name may look up another repository's project metadata (e.g. to
  // verify a cross-project write destination) without widening this project's other recall.
  const crossRepoLookup = read.context.scope === "project" && repoName !== undefined &&
    repoName !== read.context.repoName;
  let projects = await read.client.listProjects(repoName ?? read.context.repoName, read.signal);
  // Enforce the exact repo_name locally: the server is not trusted to have filtered precisely.
  if (repoName !== undefined)
    projects = projects.filter((item) => item.repo_name === repoName);
  if (!crossRepoLookup && read.projectId !== undefined)
    projects = projects.filter((item) => item.id === read.projectId);
  const result = boundedListPage(
    projects,
    read.request.offset as number | undefined,
    read.request.limit as number | undefined,
  );
  return readResult(result, { operation: read.request.operation, count: result.items.length });
}

async function readMemories(read: KnowledgeReadContext): Promise<KnowledgeToolResult> {
  const requestedProject = requestedReadProject(read);
  const searchRequest = {
    query: read.request.query as string,
    query_context: read.request.query_context as string,
    strict_project_filter: read.context.scope === "project" || requestedProject !== undefined,
    ...(requestedProject === undefined ? {} : { project_ids: [requestedProject] }),
    k: read.request.k === undefined ? 3 : read.request.k as number,
    include_links: (read.request.include_links as boolean | undefined) ?? true,
    ...(read.request.max_links_per_primary === undefined ? {} : {
      max_links_per_primary: read.request.max_links_per_primary as number,
    }),
  };
  if (!read.client.queryMemory)
    throw new Error("Grouped Forgetful memory search is unavailable.");
  const result = await read.client.queryMemory(searchRequest, read.signal);
  const primaryMemories = requestedProject === undefined
    ? result.primary_memories
    : result.primary_memories.filter((item) => inMemoryProject(item, requestedProject));
  const primaryIds = new Set(primaryMemories.map((item) => item.id));
  const linkedMemories = requestedProject === undefined
    ? result.linked_memories
    : result.linked_memories.filter((item) =>
      primaryIds.has(item.link_source_id) && inMemoryProject(item.memory, requestedProject));
  const filtered = primaryMemories.length !== result.primary_memories.length ||
    linkedMemories.length !== result.linked_memories.length;
  const grouped: MemorySearchResult = filtered
    ? {
      ...result,
      primary_memories: primaryMemories,
      linked_memories: linkedMemories,
      total_count: primaryMemories.length + linkedMemories.length,
    }
    : result;
  return readResult(grouped, {
    operation: read.request.operation,
    count: grouped.total_count,
    primary_count: grouped.primary_memories.length,
    linked_count: grouped.linked_memories.length,
    token_count: grouped.token_count,
    truncated: grouped.truncated,
  });
}

async function readMemory(read: KnowledgeReadContext): Promise<KnowledgeToolResult> {
  const value = await assertReadMemory(
    read.client, read.request.memory_id as number, read.context, read.signal,
  );
  return readResult(value, { operation: read.request.operation, id: value.id });
}

async function readEntities(read: KnowledgeReadContext): Promise<KnowledgeToolResult> {
  const requestedLimit = (read.request.limit as number | undefined) ?? 10;
  const requestedOffset = (read.request.offset as number | undefined) ?? 0;
  const searchLimit = MAX_RECORD_LIMIT;
  const knowledge = requireReadKnowledge(read);
  let values = await knowledge.searchEntities(
    read.request.query as string, searchLimit, read.signal,
  );
  const backendCount = values.length;
  values = await hydrateEntities(knowledge, values.slice(0, searchLimit), read.signal);
  const entityProjectId = requestedReadProject(read);
  if (entityProjectId !== undefined)
    values = values.filter((item) => inEntityProject(item, entityProjectId));
  const result = boundedListPage(values, requestedOffset, requestedLimit);
  const searchWindowComplete = backendCount < searchLimit;
  return readResult({
    ...result,
    search_window: searchLimit,
    search_window_complete: searchWindowComplete,
    has_more: result.truncated || !searchWindowComplete,
  }, {
    operation: read.request.operation,
    count: result.items.length,
    search_window: searchLimit,
    search_window_complete: searchWindowComplete,
  });
}

async function readEntity(read: KnowledgeReadContext): Promise<KnowledgeToolResult> {
  const value = await assertReadEntity(
    requireReadKnowledge(read), read.request.entity_id as number, read.context, read.signal,
  );
  return readResult(value, { operation: read.request.operation, id: value.id });
}

async function readEntityMemories(read: KnowledgeReadContext): Promise<KnowledgeToolResult> {
  const knowledge = requireReadKnowledge(read);
  await assertReadEntity(knowledge, read.request.entity_id as number, read.context, read.signal);
  const linked = await knowledge.getEntityMemories(read.request.entity_id as number, read.signal);
  const linkedPage = listPage(
    linked,
    read.request.offset as number | undefined,
    read.request.limit as number | undefined,
  );
  const checked = await Promise.all(linkedPage.items.map(async (item) => {
    const memory = await read.client.get(item.id, read.signal);
    if (memory.is_obsolete ||
        (read.projectId !== undefined && !inMemoryProject(memory, read.projectId)))
      return undefined;
    return item;
  }));
  const values = checked.filter(
    (item): item is { id: number; title: string } => item !== undefined,
  );
  const nextOffset = linkedPage.offset + linkedPage.items.length;
  const hasMore = nextOffset < linked.length;
  return readResult({
    offset: linkedPage.offset,
    limit: linkedPage.limit,
    items: values.map((item) => compactWriteValue(item)),
    next_offset: nextOffset,
    has_more: hasMore,
    truncated: hasMore,
  }, {
    operation: read.request.operation, count: values.length,
  });
}

async function readRelationships(read: KnowledgeReadContext): Promise<KnowledgeToolResult> {
  const knowledge = requireReadKnowledge(read);
  const entity = await assertReadEntity(
    knowledge, read.request.entity_id as number, read.context, read.signal,
  );
  const relationships = await knowledge.getRelationships(entity.id, read.signal);
  const relationshipPage = listPage(
    relationships,
    read.request.offset as number | undefined,
    read.request.limit as number | undefined,
  );
  const endpointIds = [...new Set(relationshipPage.items.flatMap((item) => [
    item.source_entity_id, item.target_entity_id,
  ]))].slice(0, MAX_RECORD_LIMIT * 2);
  const endpoints = await Promise.all(endpointIds.map((id) =>
    knowledge.getEntity(id, read.signal)));
  const endpointMap = new Map(
    endpoints.filter((item) =>
      read.projectId === undefined || inEntityProject(item, read.projectId))
      .map((item) => [item.id, item]),
  );
  const values = relationshipPage.items.filter((item) =>
    endpointMap.has(item.source_entity_id) && endpointMap.has(item.target_entity_id));
  const nextOffset = relationshipPage.offset + relationshipPage.items.length;
  const hasMore = nextOffset < relationships.length;
  return readResult({
    offset: relationshipPage.offset,
    limit: relationshipPage.limit,
    items: values,
    next_offset: nextOffset,
    has_more: hasMore,
    truncated: hasMore,
  }, {
    operation: read.request.operation, count: values.length,
  });
}

async function readDocuments(read: KnowledgeReadContext): Promise<KnowledgeToolResult> {
  let values = await requireReadKnowledge(read).listDocuments(
    requestedReadProject(read), read.signal,
  );
  if (read.projectId !== undefined)
    values = values.filter((item) => item.project_id === read.projectId);
  const result = boundedListPage(
    values,
    read.request.offset as number | undefined,
    read.request.limit as number | undefined,
  );
  return readResult(result, { operation: read.request.operation, count: result.items.length });
}

async function readDocument(read: KnowledgeReadContext): Promise<KnowledgeToolResult> {
  const value = await requireReadKnowledge(read).getDocument(
    read.request.document_id as number, read.signal,
  );
  if (read.projectId !== undefined && value.project_id !== read.projectId)
    throw new Error("The document is outside the current project.");
  const result = page(
    value,
    "content",
    read.request.offset as number | undefined,
    read.request.limit as number | undefined,
  );
  return readResult(result, { operation: read.request.operation, id: value.id });
}

async function readCodeArtifacts(read: KnowledgeReadContext): Promise<KnowledgeToolResult> {
  let values = await requireReadKnowledge(read).listCodeArtifacts(
    requestedReadProject(read), read.signal,
  );
  if (read.projectId !== undefined)
    values = values.filter((item) => item.project_id === read.projectId);
  const result = boundedListPage(
    values,
    read.request.offset as number | undefined,
    read.request.limit as number | undefined,
  );
  return readResult(result, { operation: read.request.operation, count: result.items.length });
}

async function readCodeArtifact(read: KnowledgeReadContext): Promise<KnowledgeToolResult> {
  const value = await requireReadKnowledge(read).getCodeArtifact(
    read.request.code_artifact_id as number, read.signal,
  );
  if (read.projectId !== undefined && value.project_id !== read.projectId)
    throw new Error("The code artifact is outside the current project.");
  const result = page(
    value,
    "code",
    read.request.offset as number | undefined,
    read.request.limit as number | undefined,
  );
  return readResult(result, { operation: read.request.operation, id: value.id });
}

async function readFiles(read: KnowledgeReadContext): Promise<KnowledgeToolResult> {
  let values = await requireReadKnowledge(read).listFiles(
    requestedReadProject(read), read.signal,
  );
  if (read.projectId !== undefined)
    values = values.filter((item) => item.project_id === read.projectId);
  const result = boundedListPage(
    values,
    read.request.offset as number | undefined,
    read.request.limit as number | undefined,
  );
  return readResult(result, { operation: read.request.operation, count: result.items.length });
}

async function readFile(read: KnowledgeReadContext): Promise<KnowledgeToolResult> {
  const value = await requireReadKnowledge(read).getFile(
    read.request.file_id as number, read.signal,
  );
  if (read.projectId !== undefined && value.project_id !== read.projectId)
    throw new Error("The file is outside the current project.");
  const rendered = fileContent(
    value,
    read.request.offset as number | undefined,
    read.request.limit as number | undefined,
  );
  return {
    content: rendered.content,
    details: { operation: read.request.operation, id: value.id, kind: rendered.kind },
    file: value,
  };
}

export async function executeKnowledgeRead(
  client: ForgetfulClient,
  rawRequest: KnowledgeReadRequest,
  context: KnowledgeToolContext,
  signal?: AbortSignal,
): Promise<KnowledgeToolResult> {
  const request = validateKnowledgeReadRequest(rawRequest);
  if (signal?.aborted) throw new Error("Knowledge read was cancelled.");
  const read: KnowledgeReadContext = {
    client,
    knowledge: client.knowledge,
    request,
    context,
    projectId: context.scope === "project" ? currentProject(context) : undefined,
    signal,
  };
  switch (request.operation) {
    case "list_projects": return readProjects(read);
    case "search_memories": return readMemories(read);
    case "get_memory": return readMemory(read);
    case "search_entities": return readEntities(read);
    case "get_entity": return readEntity(read);
    case "get_entity_memories": return readEntityMemories(read);
    case "get_relationships": return readRelationships(read);
    case "list_documents": return readDocuments(read);
    case "get_document": return readDocument(read);
    case "list_code_artifacts": return readCodeArtifacts(read);
    case "get_code_artifact": return readCodeArtifact(read);
    case "list_files": return readFiles(read);
    case "get_file": return readFile(read);
  }
  throw new Error("Unsupported Forgetful knowledge read operation.");
}

// Creation defaults provenance to the verified repository and current commit.
// Updates preserve existing provenance, accept supplied source files, and refresh the commit
// only in the current project; writes to another project preserve its existing provenance.
function provenance(
  context: KnowledgeToolContext,
  request: Record<string, unknown>,
): {
  source_repo?: string;
  source_files?: string[];
  encoding_version?: string;
} {
  const sourceFiles = request.source_files as string[] | undefined;
  const version = effectiveCommit(context, request);
  return {
    ...(context.repoName ? { source_repo: context.repoName } : {}),
    ...(sourceFiles ? { source_files: sourceFiles } : {}),
    ...(version ?? context.commit
      ? { encoding_version: version ?? context.commit }
      : {}),
  };
}

function effectiveCommit(
  context: KnowledgeToolContext,
  request: Record<string, unknown>,
): string | undefined {
  const supplied = request.encoding_version as string | undefined;
  const valid = (value: string): boolean => /^[a-fA-F0-9]{7,50}$/.test(value);
  if (context.commit && !valid(context.commit))
    throw new Error("The current repository commit is not supported by Forgetful.");
  if (supplied && !valid(supplied))
    throw new Error("encoding_version must be a Git commit SHA supported by Forgetful.");
  if (supplied && context.commit && supplied !== context.commit)
    throw new Error("encoding_version must match the current repository commit.");
  return context.commit ?? supplied;
}

function updateProvenance(
  existing: Provenance,
  request: Record<string, unknown>,
  context: KnowledgeToolContext,
  destinationProjectId: number,
): Provenance {
  if (destinationProjectId !== context.project?.id) {
    return {
      source_repo: existing.source_repo,
      source_files: existing.source_files,
      encoding_version: existing.encoding_version,
    };
  }
  return {
    source_repo: existing.source_repo ?? context.repoName,
    source_files: request.source_files === undefined
      ? existing.source_files : request.source_files as string[],
    encoding_version: effectiveCommit(context, request) ?? existing.encoding_version,
  };
}

async function beforeMutation(
  beforeWrite: (() => Promise<void>) | undefined,
  signal?: AbortSignal,
): Promise<void> {
  if (signal?.aborted) throw new Error("Knowledge write was cancelled.");
  if (beforeWrite) await beforeWrite();
  if (signal?.aborted) throw new Error("Knowledge write was cancelled.");
}

async function memoryInProject(
  client: ForgetfulClient,
  memoryId: number,
  projectId: number,
  signal?: AbortSignal,
  editable = false,
): Promise<Memory> {
  const value = await client.get(memoryId, signal);
  if (!value.project_ids.includes(projectId))
    throw new Error("The memory is outside the destination project.");
  if (editable && value.project_ids.length > 1)
    throw new Error("Shared memories cannot be edited from one project.");
  return value;
}

async function entityInProject(
  knowledge: KnowledgeClient,
  entityId: number,
  projectId: number,
  signal?: AbortSignal,
  editable = false,
): Promise<Entity> {
  const value = await knowledge.getEntity(entityId, signal);
  if (!value.project_ids.includes(projectId))
    throw new Error("The entity is outside the destination project.");
  if (editable && value.project_ids.length > 1)
    throw new Error("Shared entities cannot be edited from one project.");
  return value;
}

async function hydrateEntities(
  knowledge: KnowledgeClient,
  candidates: Entity[],
  signal?: AbortSignal,
): Promise<Entity[]> {
  const bounded = candidates.slice(0, 100);
  return Promise.all(bounded.map((candidate) => knowledge.getEntity(candidate.id, signal)));
}

async function validateAttachments(
  knowledge: KnowledgeClient,
  projectId: number,
  request: Record<string, unknown>,
  signal?: AbortSignal,
): Promise<void> {
  for (const id of (request.document_ids as number[] | undefined) ?? []) {
    const document = await knowledge.getDocument(id, signal);
    if (document.project_id !== projectId)
      throw new Error("A document attachment is outside the destination project.");
  }
  for (const id of (request.code_artifact_ids as number[] | undefined) ?? []) {
    const artifact = await knowledge.getCodeArtifact(id, signal);
    if (artifact.project_id !== projectId)
      throw new Error("A code artifact attachment is outside the destination project.");
  }
  for (const id of (request.file_ids as number[] | undefined) ?? []) {
    const file = await knowledge.getFile(id, signal);
    if (file.project_id !== projectId)
      throw new Error("A file attachment is outside the destination project.");
  }
}

function compactString(value: unknown): unknown {
  if (typeof value !== "string") return value;
  if (value.length > 500) return `${value.slice(0, 497)}...`;
  return value;
}

function compactObjectEntry(key: string, value: unknown, depth: number): unknown {
  if ((key === "description" || key === "notes") && typeof value === "string") {
    if (value.length > 240) return `${value.slice(0, 237)}...`;
    return value;
  }
  return compactWriteValue(value, depth + 1);
}

function compactWriteValue(value: unknown, depth = 0): unknown {
  if (value === null || typeof value !== "object") {
    return compactString(value);
  }
  if (depth > 3) return undefined;
  if (Array.isArray(value)) {
    return value.slice(0, 20).map((item) => compactWriteValue(item, depth + 1));
  }
  const omitted = new Set(["content", "code", "data"]);
  const result: Record<string, unknown> = {};
  for (const [key, item] of Object.entries(value)) {
    if (omitted.has(key)) continue;
    const compact = compactObjectEntry(key, item, depth);
    if (compact !== undefined) result[key] = compact;
  }
  return result;
}

function writeResult(value: unknown, operation: string): KnowledgeToolResult {
  return {
    content: [{ type: "text", text: json(compactWriteValue(value)) }],
    details: { operation },
  };
}

async function createMemory(
  client: ForgetfulClient,
  request: Record<string, unknown>,
  context: KnowledgeToolContext,
  projectId: number,
  signal: AbortSignal | undefined,
  beforeWrite: (() => Promise<void>) | undefined,
  checkWriteState: () => void,
): Promise<KnowledgeToolResult> {
  const knowledge = rich(client);
  const input: MemoryInput = {
    title: request.title as string,
    content: request.content as string,
    context: request.context as string,
    keywords: request.keywords as string[],
    tags: request.tags as string[],
    project_ids: [projectId],
    ...(request.importance === undefined ? {} : { importance: request.importance as number }),
    ...(request.document_ids === undefined
      ? {}
      : { document_ids: request.document_ids as number[] }),
    ...(request.code_artifact_ids === undefined
      ? {}
      : { code_artifact_ids: request.code_artifact_ids as number[] }),
    ...(request.file_ids === undefined ? {} : { file_ids: request.file_ids as number[] }),
    ...provenance(context, request),
  };
  await beforeMutation(beforeWrite, signal);
  await validateAttachments(knowledge, projectId, request, signal);
  checkWriteState();
  const created = await client.create(input, signal);
  return writeResult({ status: "created", memory: created }, "create_memory");
}

async function createEntity(
  knowledge: KnowledgeClient,
  request: Record<string, unknown>,
  context: KnowledgeToolContext,
  projectId: number,
  signal: AbortSignal | undefined,
  beforeWrite: (() => Promise<void>) | undefined,
  checkWriteState: () => void,
): Promise<KnowledgeToolResult> {
  const input: EntityInput = {
    name: request.name as string,
    entity_type: request.entity_type as EntityType,
    project_ids: [projectId],
    tags: (request.tags as string[] | undefined) ?? [],
    aka: (request.aka as string[] | undefined) ?? [],
    ...(request.custom_type === undefined ? {} : { custom_type: request.custom_type as string }),
    ...(request.notes === undefined ? {} : { notes: request.notes as string }),
    ...provenance(context, request),
  };
  await beforeMutation(beforeWrite, signal);
  checkWriteState();
  return writeResult(
    { status: "created", entity: await knowledge.createEntity(input, signal) },
    "create_entity",
  );
}

async function createDocument(
  knowledge: KnowledgeClient,
  request: Record<string, unknown>,
  context: KnowledgeToolContext,
  projectId: number,
  signal: AbortSignal | undefined,
  beforeWrite: (() => Promise<void>) | undefined,
  checkWriteState: () => void,
): Promise<KnowledgeToolResult> {
  const input: DocumentInput = {
    title: request.title as string,
    description: request.description as string,
    content: request.content as string,
    document_type: request.document_type as string | undefined,
    tags: (request.tags as string[] | undefined) ?? [],
    project_id: projectId,
    ...provenance(context, request),
  };
  await beforeMutation(beforeWrite, signal);
  checkWriteState();
  return writeResult(
    { status: "created", document: await knowledge.createDocument(input, signal) },
    "create_document",
  );
}

async function createCodeArtifact(
  knowledge: KnowledgeClient,
  request: Record<string, unknown>,
  context: KnowledgeToolContext,
  projectId: number,
  signal: AbortSignal | undefined,
  beforeWrite: (() => Promise<void>) | undefined,
  checkWriteState: () => void,
): Promise<KnowledgeToolResult> {
  const input: CodeArtifactInput = {
    title: request.title as string,
    description: request.description as string,
    code: request.code as string,
    language: request.language as string,
    tags: (request.tags as string[] | undefined) ?? [],
    project_id: projectId,
    ...provenance(context, request),
  };
  await beforeMutation(beforeWrite, signal);
  checkWriteState();
  return writeResult(
    { status: "created", code_artifact: await knowledge.createCodeArtifact(input, signal) },
    "create_code_artifact",
  );
}

async function replacementMemory(write: KnowledgeWriteContext): Promise<Memory> {
  const { client, knowledge, request, context, projectId, signal, beforeWrite,
    checkWriteState } = write;
  const replacementId = request.replacement_memory_id as number | undefined;
  if (replacementId !== undefined) {
    const replacement = await memoryInProject(client, replacementId, projectId, signal, true);
    if (replacement.is_obsolete) throw new Error("The replacement memory is obsolete.");
    return replacement;
  }
  const input: MemoryInput = {
    title: request.title as string,
    content: request.content as string,
    context: typeof request.context === "string"
      ? replacementMemoryContext(request.context)
      : request.context as string,
    keywords: (request.keywords as string[] | undefined) ?? [],
    tags: (request.tags as string[] | undefined) ?? [],
    project_ids: [projectId],
    ...(request.importance === undefined ? {} : { importance: request.importance as number }),
    ...(request.document_ids === undefined
      ? {}
      : { document_ids: request.document_ids as number[] }),
    ...(request.code_artifact_ids === undefined
      ? {}
      : { code_artifact_ids: request.code_artifact_ids as number[] }),
    ...(request.file_ids === undefined ? {} : { file_ids: request.file_ids as number[] }),
    ...provenance(context, request),
  };
  await beforeMutation(beforeWrite, signal);
  const oldMemory = await memoryInProject(
    client, request.memory_id as number, projectId, signal, true,
  );
  if (oldMemory.is_obsolete)
    throw new Error("The selected memory is already obsolete or was superseded differently.");
  await validateAttachments(knowledge, projectId, request, signal);
  checkWriteState();
  const created = await client.create(input, signal);
  return client.get(created.id, signal);
}

interface KnowledgeWriteContext {
  client: ForgetfulClient;
  knowledge: KnowledgeClient;
  request: KnowledgeWriteRequest;
  context: KnowledgeToolContext;
  projectId: number;
  signal?: AbortSignal;
  beforeWrite?: () => Promise<void>;
  checkWriteState: () => void;
}

async function updateMemory(write: KnowledgeWriteContext): Promise<KnowledgeToolResult> {
  const { client, knowledge, request, context, projectId, signal, beforeWrite } = write;
  await beforeMutation(beforeWrite, signal);
  const memory = await memoryInProject(
    client, request.memory_id as number, projectId, signal, true,
  );
  await validateAttachments(knowledge, projectId, request, signal);
  const input: Partial<MemoryInput> = {
    ...(request.title === undefined ? {} : { title: request.title as string }),
    ...(request.content === undefined ? {} : { content: request.content as string }),
    ...(request.context === undefined ? {} : { context: request.context as string }),
    ...(request.keywords === undefined ? {} : { keywords: request.keywords as string[] }),
    ...(request.tags === undefined ? {} : { tags: request.tags as string[] }),
    ...(request.importance === undefined ? {} : { importance: request.importance as number }),
    ...(request.document_ids === undefined
      ? {}
      : { document_ids: request.document_ids as number[] }),
    ...(request.code_artifact_ids === undefined
      ? {}
      : { code_artifact_ids: request.code_artifact_ids as number[] }),
    ...(request.file_ids === undefined ? {} : { file_ids: request.file_ids as number[] }),
    ...updateProvenance(memory, request, context, projectId),
  };
  write.checkWriteState();
  return writeResult({ status: "updated", memory: await knowledge.updateMemory(
    memory.id, input, signal,
  ) }, request.operation);
}

async function supersedeMemory(write: KnowledgeWriteContext): Promise<KnowledgeToolResult> {
  const { client, request, projectId, signal, beforeWrite } = write;
  const oldMemory = await memoryInProject(
    client, request.memory_id as number, projectId, signal, true,
  );
  const requestedReplacement = request.replacement_memory_id as number | undefined;
  if (oldMemory.is_obsolete) {
    if (requestedReplacement !== undefined && oldMemory.superseded_by === requestedReplacement) {
      return writeResult({ status: "already", old_memory_id: oldMemory.id,
        replacement_memory_id: requestedReplacement }, request.operation);
    }
    throw new Error("The selected memory is already obsolete or was superseded differently.");
  }
  const replacement = await replacementMemory(write);
  if (replacement.id === oldMemory.id) throw new Error("A memory cannot supersede itself.");
  await beforeMutation(beforeWrite, signal);
  const currentOld = await memoryInProject(client, oldMemory.id, projectId, signal, true);
  const currentReplacement = await memoryInProject(client, replacement.id, projectId, signal, true);
  if (currentOld.is_obsolete && currentOld.superseded_by === replacement.id) {
    return writeResult({ status: "already", old_memory_id: oldMemory.id,
      replacement_memory_id: replacement.id }, request.operation);
  }
  if (currentOld.is_obsolete)
    throw new Error("The selected memory is already obsolete or was superseded differently.");
  if (currentReplacement.is_obsolete) throw new Error("The replacement memory is obsolete.");
  write.checkWriteState();
  await client.supersede(oldMemory.id, replacement.id, request.reason as string, signal);
  return writeResult({ status: "superseded", old_memory_id: oldMemory.id,
    replacement_memory_id: replacement.id }, request.operation);
}

async function linkMemories(write: KnowledgeWriteContext): Promise<KnowledgeToolResult> {
  const { client, knowledge, request, projectId, signal, beforeWrite } = write;
  await beforeMutation(beforeWrite, signal);
  await memoryInProject(client, request.memory_id as number, projectId, signal);
  for (const id of request.related_memory_ids as number[])
    await memoryInProject(client, id, projectId, signal);
  write.checkWriteState();
  await knowledge.linkMemories(
    request.memory_id as number, request.related_memory_ids as number[], signal,
  );
  return writeResult({ status: "linked", memory_id: request.memory_id }, request.operation);
}

async function updateEntity(write: KnowledgeWriteContext): Promise<KnowledgeToolResult> {
  const { knowledge, request, context, projectId, signal, beforeWrite } = write;
  await beforeMutation(beforeWrite, signal);
  const entity = await entityInProject(
    knowledge, request.entity_id as number, projectId, signal, true,
  );
  const input: Partial<EntityInput> = {
    ...(request.name === undefined ? {} : { name: request.name as string }),
    ...(request.entity_type === undefined
      ? {}
      : { entity_type: request.entity_type as EntityType }),
    ...(request.custom_type === undefined ? {} : { custom_type: request.custom_type as string }),
    ...(request.notes === undefined ? {} : { notes: request.notes as string }),
    ...(request.tags === undefined ? {} : { tags: request.tags as string[] }),
    ...(request.aka === undefined ? {} : { aka: request.aka as string[] }),
    project_ids: [...entity.project_ids],
    ...updateProvenance(entity, request, context, projectId),
  };
  write.checkWriteState();
  return writeResult({ status: "updated", entity: await knowledge.updateEntity(
    entity.id, input, signal,
  ) }, request.operation);
}

async function linkEntityMemory(write: KnowledgeWriteContext): Promise<KnowledgeToolResult> {
  const { client, knowledge, request, projectId, signal, beforeWrite } = write;
  await beforeMutation(beforeWrite, signal);
  await entityInProject(knowledge, request.entity_id as number, projectId, signal);
  await memoryInProject(client, request.memory_id as number, projectId, signal);
  write.checkWriteState();
  await knowledge.linkEntityMemory(
    request.entity_id as number, request.memory_id as number, signal,
  );
  return writeResult(
    { status: "linked", entity_id: request.entity_id, memory_id: request.memory_id },
    request.operation,
  );
}

async function createRelationship(write: KnowledgeWriteContext): Promise<KnowledgeToolResult> {
  const { knowledge, request, context, projectId, signal, beforeWrite } = write;
  await beforeMutation(beforeWrite, signal);
  await entityInProject(knowledge, request.source_entity_id as number, projectId, signal);
  await entityInProject(knowledge, request.target_entity_id as number, projectId, signal);
  const input: EntityRelationshipInput = {
    source_entity_id: request.source_entity_id as number,
    target_entity_id: request.target_entity_id as number,
    relationship_type: request.relationship_type as string,
    ...provenance(context, request),
  };
  write.checkWriteState();
  return writeResult({ status: "created", relationship: await knowledge.createRelationship(
    input, signal,
  ) }, request.operation);
}

async function updateDocument(write: KnowledgeWriteContext): Promise<KnowledgeToolResult> {
  const { knowledge, request, context, projectId, signal, beforeWrite } = write;
  await beforeMutation(beforeWrite, signal);
  const document = await knowledge.getDocument(request.document_id as number, signal);
  if (document.project_id !== projectId)
    throw new Error("The document is outside the destination project.");
  const input: Partial<DocumentInput> = {
    ...(request.title === undefined ? {} : { title: request.title as string }),
    ...(request.description === undefined ? {} : { description: request.description as string }),
    ...(request.content === undefined ? {} : { content: request.content as string }),
    ...(request.document_type === undefined
      ? {}
      : { document_type: request.document_type as string }),
    ...(request.tags === undefined ? {} : { tags: request.tags as string[] }),
    project_id: document.project_id,
    ...updateProvenance(document, request, context, projectId),
  };
  write.checkWriteState();
  return writeResult({ status: "updated", document: await knowledge.updateDocument(
    document.id, input, signal,
  ) }, request.operation);
}

async function updateCodeArtifact(write: KnowledgeWriteContext): Promise<KnowledgeToolResult> {
  const { knowledge, request, context, projectId, signal, beforeWrite } = write;
  await beforeMutation(beforeWrite, signal);
  const artifact = await knowledge.getCodeArtifact(request.code_artifact_id as number, signal);
  if (artifact.project_id !== projectId)
    throw new Error("The code artifact is outside the destination project.");
  const input: Partial<CodeArtifactInput> = {
    ...(request.title === undefined ? {} : { title: request.title as string }),
    ...(request.description === undefined ? {} : { description: request.description as string }),
    ...(request.code === undefined ? {} : { code: request.code as string }),
    ...(request.language === undefined ? {} : { language: request.language as string }),
    ...(request.tags === undefined ? {} : { tags: request.tags as string[] }),
    project_id: artifact.project_id,
    ...updateProvenance(artifact, request, context, projectId),
  };
  write.checkWriteState();
  return writeResult({ status: "updated", code_artifact: await knowledge.updateCodeArtifact(
    artifact.id, input, signal,
  ) }, request.operation);
}

export async function executeKnowledgeWrite(
  client: ForgetfulClient,
  rawRequest: KnowledgeWriteRequest,
  context: KnowledgeToolContext,
  signal?: AbortSignal,
  beforeWrite?: () => Promise<void>,
  checkWriteState?: () => void,
): Promise<KnowledgeToolResult> {
  rejectSensitiveInput(rawRequest);
  const request = validateKnowledgeWriteRequest(rawRequest);
  if (signal?.aborted) throw new Error("Knowledge write was cancelled.");
  effectiveCommit(context, request);
  const requestedProject = request.project_id as number | undefined;
  const destination = await resolveWriteProject(client, context, requestedProject, signal);
  const projectId = destination.id;
  const beforeDestinationMutation = async () => {
    if (beforeWrite) await beforeWrite();
    const currentDestination = await resolveWriteProject(
      client, context, requestedProject, signal,
    );
    if (
      currentDestination.id !== destination.id ||
      currentDestination.repoName !== destination.repoName
    ) {
      throw new Error("The Forgetful destination project changed. Retry the operation.");
    }
    if (checkWriteState) checkWriteState();
  };
  const checkMutationState = () => {
    if (signal?.aborted) throw new Error("Knowledge write was cancelled.");
    if (checkWriteState) checkWriteState();
  };
  const knowledge = rich(client);
  const write: KnowledgeWriteContext = {
    client, knowledge, request, context, projectId, signal,
    beforeWrite: beforeDestinationMutation,
    checkWriteState: checkMutationState,
  };
  switch (request.operation) {
    case "create_memory":
      return createMemory(
        client, request, context, projectId, signal, beforeDestinationMutation,
        checkMutationState,
      );
    case "create_entity":
      return createEntity(
        knowledge, request, context, projectId, signal, beforeDestinationMutation,
        checkMutationState,
      );
    case "create_document":
      return createDocument(
        knowledge, request, context, projectId, signal, beforeDestinationMutation,
        checkMutationState,
      );
    case "create_code_artifact":
      return createCodeArtifact(
        knowledge, request, context, projectId, signal, beforeDestinationMutation,
        checkMutationState,
      );
    case "update_memory": return updateMemory(write);
    case "supersede_memory": return supersedeMemory(write);
    case "link_memories": return linkMemories(write);
    case "update_entity": return updateEntity(write);
    case "link_entity_memory": return linkEntityMemory(write);
    case "create_relationship": return createRelationship(write);
    case "update_document": return updateDocument(write);
    case "update_code_artifact": return updateCodeArtifact(write);
  }
  throw new Error("Unsupported Forgetful knowledge write operation.");
}
